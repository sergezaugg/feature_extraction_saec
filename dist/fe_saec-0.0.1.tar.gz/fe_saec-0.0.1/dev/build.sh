python -m venv ./

python -m pip install --upgrade build

python -m build



pip uninstall fe_saec 

python -m venv ./

pip install dist/fe_saec-0.0.1-py3-none-any.whl

pip install --force-reinstall torch torchvision --index-url https://download.pytorch.org/whl/cu126




